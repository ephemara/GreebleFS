import { useState, useEffect, useRef, useCallback, useMemo, type CSSProperties } from 'react';
import { invoke } from '@tauri-apps/api/core';
import {
  getCurrentWindow,
  PhysicalSize,
  PhysicalPosition,
  primaryMonitor,
} from '@tauri-apps/api/window';
import { listen } from '@tauri-apps/api/event';
import { Check, Droplet, GripVertical, LayoutGrid, Terminal as TerminalIcon, X } from 'lucide-react';
import { ensureFontFamilyLoaded, resolveOverlayAppearance, type ResolvedOverlayAppearance } from './config/appearance';
import { createBuiltInPanelDefinitions, type OverlayPanelDefinition } from './panels/panelRegistry';
import { getNextActivePanelId, reorderPanelIds, togglePanelId } from './components/panelUtils';
import { useSettingsStore } from './store/settingsStore';
import { useTerminalStore } from './store/terminalStore';

const LOGICAL_PADDING = 12;

function parseExternalArgs(raw: string): string[] {
  return raw
    .split(/\r?\n/g)
    .map(value => value.trim())
    .filter(Boolean);
}

// ─── Main App ─────────────────────────────────────────────────────────────────

function App() {
  const [isOpen, setIsOpen] = useState(false);
  const [activePanelId, setActivePanelId] = useState<string | null>('terminal');
  const isOpenRef = useRef(false);
  isOpenRef.current = isOpen;

  const settings = useSettingsStore(s => s.settings.terminal);
  const appearance = useSettingsStore(s => s.settings.appearance);
  const updateAppearance = useSettingsStore(s => s.updateAppearance);
  const { initStore, addDirectoryBookmark } = useTerminalStore();
  const resolvedAppearance = useMemo(
    () => resolveOverlayAppearance({
      activeThemeId: appearance.activeThemeId,
      customThemes: appearance.customThemes,
      uiFontFamily: appearance.uiFontFamily,
      monoFontFamily: settings.fontFamily,
    }),
    [appearance.activeThemeId, appearance.customThemes, appearance.uiFontFamily, settings.fontFamily],
  );
  const theme = resolvedAppearance.theme;
  const accent = theme.palette.accent;

  // ── Boot store ──
  useEffect(() => { initStore(); }, [initStore]);

  useEffect(() => {
    ensureFontFamilyLoaded(resolvedAppearance.fonts.ui);
    ensureFontFamilyLoaded(resolvedAppearance.fonts.mono);
  }, [resolvedAppearance.fonts.mono, resolvedAppearance.fonts.ui]);

  // ── Position & show ──
  const positionAndShow = useCallback(async () => {
    try {
      const win = getCurrentWindow();
      const scaleFactor = await win.scaleFactor();
      const monitor = await primaryMonitor();
      if (!monitor) return;

      const store = useSettingsStore.getState().settings.terminal;
      const physPad = Math.round(LOGICAL_PADDING * scaleFactor);
      const wa = monitor.workArea;

      const TARGET_HEIGHT = store.overlayHeight || 420;
      const physHeight = Math.min(
        Math.round(TARGET_HEIGHT * scaleFactor),
        wa.size.height - physPad * 2,
      );

      const savedPhysW = store.overlayWidth > 0
        ? Math.round(store.overlayWidth * scaleFactor)
        : null;
      const physWidth = savedPhysW
        ? Math.min(savedPhysW, wa.size.width - physPad * 2)
        : wa.size.width - physPad * 2;

      const newX = wa.position.x + physPad;
      const newY = wa.position.y + wa.size.height - physHeight - physPad;

      await win.setSize(new PhysicalSize(Math.max(physWidth, 400), physHeight));
      await win.setPosition(new PhysicalPosition(newX, newY));
      await win.show();
      await win.setFocus();
      setIsOpen(true);
    } catch (e) {
      console.warn('OverlayTerm: failed to position/show', e);
    }
  }, []);

  const hideOverlay = useCallback(async () => {
    setIsOpen(false);
    setTimeout(async () => {
      try { await getCurrentWindow().hide(); } catch { /* ignore */ }
    }, 400);
  }, []);

  const toggle = useCallback(() => {
    if (isOpenRef.current) hideOverlay();
    else positionAndShow();
  }, [positionAndShow, hideOverlay]);

  // ── Listen for Rust Ctrl+Space event ──
  useEffect(() => {
    let unlisten: (() => void) | null = null;
    listen('overlay://toggle-request', () => toggle())
      .then(fn => { unlisten = fn; })
      .catch(err => console.warn('overlay listen failed:', err));
    return () => { unlisten?.(); };
  }, [toggle]);

  // ── Escape to close ──
  useEffect(() => {
    const handler = (e: KeyboardEvent) => {
      if (e.key === 'Escape' && isOpenRef.current) { e.preventDefault(); hideOverlay(); }
    };
    window.addEventListener('keydown', handler);
    return () => window.removeEventListener('keydown', handler);
  }, [hideOverlay]);

  // ── Persist resize ──
  useEffect(() => {
    const unlistenResize = getCurrentWindow().onResized(async ev => {
      const factor = await getCurrentWindow().scaleFactor();
      const logH = Math.round(ev.payload.height / factor);
      const logW = Math.round(ev.payload.width / factor);
      useSettingsStore.getState().updateTerminal({
        overlayHeight: Math.max(logH, 150),
        overlayWidth:  Math.max(logW, 300),
      });
    });
    return () => { unlistenResize.then(fn => fn()); };
  }, []);

  // ── Explorer → Terminal bridge ──
  const handleOpenInTerminal = useCallback(async (path: string) => {
    if (settings.preferredOpenMode === 'external') {
      await invoke('terminal_open_external', {
        request: {
          workingDir: path,
          profile: settings.externalTerminalProfile,
          executable: settings.externalTerminalCommand || null,
          args: parseExternalArgs(settings.externalTerminalArgs),
          shell: settings.shell,
        },
      }).catch(error => {
        console.warn('OverlayTerm: failed to open external terminal', error);
      });
      hideOverlay();
      return;
    }

    setActivePanelId('terminal');
    // Small delay so the terminal tab renders before we inject the cd
    setTimeout(() => {
      window.dispatchEvent(new CustomEvent('overlayterm:cdinject', { detail: path }));
    }, 80);
  }, [hideOverlay, settings.externalTerminalArgs, settings.externalTerminalCommand, settings.externalTerminalProfile, settings.preferredOpenMode, settings.shell]);

  const handleAddBookmark = useCallback(async (name: string, path: string) => {
    await addDirectoryBookmark({ id: crypto.randomUUID(), name, value: path });
  }, [addDirectoryBookmark]);

  const panelDefinitions = useMemo<OverlayPanelDefinition[]>(
    () => createBuiltInPanelDefinitions({
      appearance: resolvedAppearance,
      isOpen,
      hideOverlay,
      onOpenInTerminal: handleOpenInTerminal,
      onAddBookmark: handleAddBookmark,
    }),
    [handleAddBookmark, handleOpenInTerminal, hideOverlay, isOpen, resolvedAppearance],
  );
  const panelLookup = useMemo(
    () => new Map(panelDefinitions.map(panel => [panel.id, panel])),
    [panelDefinitions],
  );
  const defaultOpenPanelIds = useMemo(
    () => panelDefinitions.filter(panel => panel.defaultOpen).map(panel => panel.id),
    [panelDefinitions],
  );
  const [openPanelIds, setOpenPanelIds] = useState<string[]>(defaultOpenPanelIds);
  const openPanels = openPanelIds
    .map(id => panelLookup.get(id))
    .filter((panel): panel is OverlayPanelDefinition => Boolean(panel));

  useEffect(() => {
    setOpenPanelIds(current => current.filter(id => panelLookup.has(id)));
    setActivePanelId(current => {
      if (!current) return null;
      return panelLookup.has(current) ? current : null;
    });
  }, [panelLookup]);

  useEffect(() => {
    if (activePanelId) return;
    if (openPanelIds.length === 0) return;
    setActivePanelId(openPanelIds[0]);
  }, [activePanelId, openPanelIds]);

  const handleTogglePanel = useCallback((panelId: string) => {
    setOpenPanelIds(current => {
      const next = togglePanelId(current, panelId);
      const isOpening = !current.includes(panelId);

      setActivePanelId(active => {
        if (isOpening) return panelId;
        if (active === panelId) return getNextActivePanelId(current, panelId);
        return active;
      });

      return next;
    });
  }, []);

  const handleClosePanel = useCallback((panelId: string) => {
    setOpenPanelIds(current => {
      const next = current.filter(id => id !== panelId);
      setActivePanelId(active => (active === panelId ? getNextActivePanelId(current, panelId) : active));
      return next;
    });
  }, []);

  const handleReorderPanels = useCallback((draggedId: string, targetId: string) => {
    setOpenPanelIds(current => reorderPanelIds(current, draggedId, targetId));
  }, []);

  const slideClass = isOpen ? 'translate-y-0' : 'translate-y-full';
  const appOpacity = appearance.appOpacity ?? 1.0;
  const appZoom = appearance.appZoom ?? 1.0;
  const appBlur = appearance.appBlur ?? true;
  const clampedAppOpacity = Math.min(Math.max(appOpacity, 0.15), 1);
  const clampedAppZoom = Math.min(Math.max(appZoom, 0.7), 1.35);
  const scaledWidth = `${100 / clampedAppZoom}%`;
  const scaledHeight = `${100 / clampedAppZoom}%`;

  return (
    <div
      className="w-screen h-screen bg-transparent overflow-hidden"
      style={resolvedAppearance.cssVars as CSSProperties}
    >
      <div
        className={`absolute left-0 bottom-0 flex flex-col overflow-hidden transition-all duration-[360ms] ease-[cubic-bezier(0.22,1,0.36,1)] ${slideClass}`}
        style={{
          width: scaledWidth,
          height: scaledHeight,
          transform: `scale(${clampedAppZoom})`,
          transformOrigin: 'bottom left',
          opacity: isOpen ? clampedAppOpacity : 0,
          backgroundColor: appBlur ? theme.palette.shellBackground : theme.palette.shellBackgroundSolid,
          backgroundImage: theme.effects.backgroundImage,
          backgroundSize: theme.effects.backgroundSize,
          backgroundPosition: theme.effects.backgroundPosition,
          backdropFilter: appBlur ? 'blur(24px)' : 'none',
          WebkitBackdropFilter: appBlur ? 'blur(24px)' : 'none',
          color: theme.palette.textPrimary,
          fontFamily: resolvedAppearance.fonts.ui,
          boxShadow: theme.effects.overlayShadow,
          borderTop: `1px solid ${accent}40`,
        }}
      >
        {/* ══ Grab handle ══ */}
        <div
          className="h-[4px] shrink-0 cursor-ns-resize select-none"
          style={{ background: `linear-gradient(90deg, transparent 0%, ${accent}99 30%, ${accent} 50%, ${accent}99 70%, transparent 100%)` }}
          onPointerDown={e => {
            if (e.buttons === 1) { e.preventDefault(); getCurrentWindow().startResizeDragging('North').catch(() => {}); }
          }}
        />

        {/* ══ App-level Top Bar ══ */}
        <TopBar
          appearance={resolvedAppearance}
          panels={panelDefinitions}
          openPanelIds={openPanelIds}
          activePanelId={activePanelId}
          onPanelSelect={setActivePanelId}
          onPanelToggle={handleTogglePanel}
          onPanelClose={handleClosePanel}
          onPanelReorder={handleReorderPanels}
          onClose={hideOverlay}
          accent={accent}
          opacity={clampedAppOpacity}
          onOpacityChange={(v) => updateAppearance({ appOpacity: Math.min(Math.max(v, 0.15), 1) })}
          zoom={clampedAppZoom}
          onZoomChange={(v) => updateAppearance({ appZoom: Math.min(Math.max(v, 0.7), 1.35) })}
          blur={appBlur}
          onBlurChange={(v) => updateAppearance({ appBlur: v })}
        />

        {/* ══ Content ══ */}
        <div className="flex flex-1 min-h-0 overflow-hidden">
          {panelDefinitions.map(panel => {
            const isPanelOpen = openPanelIds.includes(panel.id);
            const isActive = panel.id === activePanelId;
            const shouldMount = panel.keepMounted ? true : isPanelOpen && isActive;

            if (!shouldMount) return null;

            return (
              <div
                key={panel.id}
                style={{
                  flex: 1,
                  display: isPanelOpen && isActive ? 'flex' : 'none',
                  flexDirection: 'column',
                  overflow: 'hidden',
                }}
              >
                {panel.render()}
              </div>
            );
          })}

          {openPanels.length === 0 && (
            <div style={{
              flex: 1,
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              color: theme.palette.textMuted,
              fontSize: 13,
              background: theme.palette.appBackground,
              fontFamily: resolvedAppearance.fonts.ui,
            }}
            >
              No panels are open. Use the panel menu to bring one back.
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

// ─── TopBar ───────────────────────────────────────────────────────────────────

function TopBar({ appearance, panels, openPanelIds, activePanelId, onPanelSelect, onPanelToggle, onPanelClose, onPanelReorder, onClose, accent, opacity, onOpacityChange, zoom, onZoomChange, blur, onBlurChange }: {
  appearance: ResolvedOverlayAppearance;
  panels: OverlayPanelDefinition[];
  openPanelIds: string[];
  activePanelId: string | null;
  onPanelSelect: (panelId: string | null) => void;
  onPanelToggle: (panelId: string) => void;
  onPanelClose: (panelId: string) => void;
  onPanelReorder: (draggedId: string, targetId: string) => void;
  onClose: () => void;
  accent: string;
  opacity: number;
  onOpacityChange: (v: number) => void;
  zoom: number;
  onZoomChange: (v: number) => void;
  blur: boolean;
  onBlurChange: (v: boolean) => void;
}) {
  const BG = appearance.theme.palette.topBarBackground;
  const MENU_BG = appearance.theme.palette.topBarMenuBackground;
  const BORDER = appearance.theme.palette.border;
  const MUTED = appearance.theme.palette.textMuted;
  const TEXT = appearance.theme.palette.textPrimary;
  const uiFont = appearance.fonts.ui;
  const monoFont = appearance.fonts.mono;
  const menuRef = useRef<HTMLDivElement | null>(null);
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [draggedPanelId, setDraggedPanelId] = useState<string | null>(null);
  const openPanels = useMemo(
    () => openPanelIds
      .map(id => panels.find(panel => panel.id === id))
      .filter((panel): panel is OverlayPanelDefinition => Boolean(panel)),
    [openPanelIds, panels],
  );

  useEffect(() => {
    if (!isMenuOpen) return;

    const handlePointerDown = (event: PointerEvent) => {
      if (!menuRef.current?.contains(event.target as Node)) {
        setIsMenuOpen(false);
      }
    };

    window.addEventListener('pointerdown', handlePointerDown);
    return () => window.removeEventListener('pointerdown', handlePointerDown);
  }, [isMenuOpen]);

  return (
    <div style={{
      display: 'flex', alignItems: 'stretch', height: 38, flexShrink: 0,
      background: BG, borderBottom: `1px solid ${BORDER}`,
    }}>
      {/* Brand */}
      <div style={{
        display: 'flex', alignItems: 'center', gap: 8, padding: '0 14px',
        borderRight: `1px solid ${BORDER}`, flexShrink: 0,
      }}>
        <div style={{
          width: 20, height: 20, borderRadius: 5, display: 'flex', alignItems: 'center', justifyContent: 'center',
          background: `${accent}28`, border: `1px solid ${accent}55`,
        }}>
          <TerminalIcon size={10} style={{ color: accent }} />
        </div>
        <span style={{ fontSize: 11, fontWeight: 700, letterSpacing: '0.12em', textTransform: 'uppercase', color: MUTED, fontFamily: uiFont, userSelect: 'none' }}>
          Snapyard
        </span>
      </div>

      {/* Panels */}
      <div style={{ display: 'flex', alignItems: 'stretch', flex: 1, minWidth: 0 }}>
        <div ref={menuRef} style={{ position: 'relative', flexShrink: 0, borderRight: `1px solid ${BORDER}` }}>
          <button
            onClick={() => setIsMenuOpen(open => !open)}
            title="Toggle Panels"
            style={{
              height: '100%',
              display: 'flex',
              alignItems: 'center',
              gap: 8,
              padding: '0 14px',
              background: isMenuOpen ? `${accent}14` : 'transparent',
              border: 'none',
              color: isMenuOpen ? TEXT : MUTED,
              cursor: 'pointer',
              fontSize: 11,
              fontWeight: 700,
              letterSpacing: '0.08em',
              textTransform: 'uppercase',
              fontFamily: uiFont,
            }}
          >
            <LayoutGrid size={13} style={{ color: isMenuOpen ? accent : MUTED }} />
            Panels
          </button>

          {isMenuOpen && (
            <div style={{
              position: 'absolute',
              top: 'calc(100% + 8px)',
              left: 8,
              width: 260,
              background: MENU_BG,
              border: `1px solid ${BORDER}`,
              borderRadius: 12,
              boxShadow: appearance.theme.effects.shadow,
              padding: 8,
              zIndex: 50,
            }}
            >
              <div style={{
                padding: '6px 8px 10px',
                fontSize: 10,
                color: MUTED,
                textTransform: 'uppercase',
                letterSpacing: '0.08em',
                fontWeight: 700,
              }}
              >
                Available Panels
              </div>

              {panels.map(panel => {
                const isOpen = openPanelIds.includes(panel.id);
                const isActive = panel.id === activePanelId;
                return (
                  <button
                    key={panel.id}
                    onClick={() => {
                      onPanelToggle(panel.id);
                      setIsMenuOpen(false);
                    }}
                    style={{
                      width: '100%',
                      display: 'flex',
                      alignItems: 'center',
                      gap: 10,
                      padding: '10px 12px',
                      border: 'none',
                      borderRadius: 10,
                      background: isActive ? `${accent}16` : 'transparent',
                      color: TEXT,
                      cursor: 'pointer',
                      textAlign: 'left',
                      marginBottom: 4,
                    }}
                  >
                    <span style={{
                      width: 16,
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'center',
                      color: isOpen ? accent : 'transparent',
                    }}
                    >
                      <Check size={13} />
                    </span>
                    <span style={{ display: 'flex', color: isActive ? accent : MUTED }}>{panel.icon}</span>
                    <span style={{ flex: 1, minWidth: 0 }}>
                      <span style={{ display: 'block', fontSize: 12, fontWeight: 700 }}>{panel.label}</span>
                      <span style={{ display: 'block', marginTop: 3, fontSize: 11, color: MUTED, lineHeight: 1.4 }}>
                        {panel.description}
                      </span>
                    </span>
                  </button>
                );
              })}
            </div>
          )}
        </div>

        <div style={{ display: 'flex', alignItems: 'stretch', flex: 1, minWidth: 0, overflowX: 'auto', overflowY: 'hidden' }}>
          {openPanels.map(panel => {
            const isActive = panel.id === activePanelId;
            const isDragged = draggedPanelId === panel.id;
            return (
              <button
                key={panel.id}
                draggable
                onClick={() => onPanelSelect(panel.id)}
                onDragStart={() => setDraggedPanelId(panel.id)}
                onDragEnd={() => setDraggedPanelId(null)}
                onDragOver={event => {
                  event.preventDefault();
                }}
                onDrop={event => {
                  event.preventDefault();
                  if (draggedPanelId && draggedPanelId !== panel.id) {
                    onPanelReorder(draggedPanelId, panel.id);
                  }
                  setDraggedPanelId(null);
                }}
                style={{
                  display: 'flex',
                  alignItems: 'center',
                  gap: 8,
                  padding: '0 12px',
                  cursor: 'pointer',
                  background: isActive ? `${accent}14` : 'transparent',
                  border: 'none',
                  borderBottom: `2px solid ${isActive ? accent : 'transparent'}`,
                  borderRight: `1px solid ${BORDER}`,
                  color: isActive ? TEXT : MUTED,
                  fontSize: 12,
                  fontWeight: isActive ? 700 : 500,
                  fontFamily: uiFont,
                  transition: 'background 0.15s, color 0.15s, border-color 0.15s, opacity 0.15s',
                  flexShrink: 0,
                  userSelect: 'none',
                  opacity: isDragged ? 0.45 : 1,
                }}
              >
                <span style={{ display: 'flex', color: isActive ? accent : MUTED }}>
                  <GripVertical size={11} />
                </span>
                <span style={{ display: 'flex', color: isActive ? accent : MUTED }}>{panel.icon}</span>
                <span>{panel.label}</span>
                {isActive && <span style={{ width: 5, height: 5, borderRadius: '50%', background: accent }} />}
                <span
                  onClick={event => {
                    event.stopPropagation();
                    onPanelClose(panel.id);
                  }}
                  title={`Close ${panel.label}`}
                  style={{
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    width: 16,
                    height: 16,
                    borderRadius: 4,
                    color: MUTED,
                  }}
                >
                  <X size={11} />
                </span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Controls */}
      <div style={{ display: 'flex', alignItems: 'center', gap: 6, padding: '0 8px', borderLeft: `1px solid ${BORDER}`, flexShrink: 0 }}>
        
        {/* Blur Control */}
        <button
          onClick={() => onBlurChange(!blur)}
          title={blur ? "Disable Glassmorphism Blur" : "Enable Glassmorphism Blur"}
          style={{
            background: blur ? `${accent}22` : 'transparent',
            border: `1px solid ${blur ? accent : BORDER}`,
            color: blur ? accent : MUTED,
            width: 22, height: 22, borderRadius: 5,
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            cursor: 'pointer', transition: 'all 0.15s',
            marginRight: 4
          }}
          onMouseEnter={e => { if (!blur) { e.currentTarget.style.color = TEXT; e.currentTarget.style.borderColor = TEXT; } }}
          onMouseLeave={e => { if (!blur) { e.currentTarget.style.color = MUTED; e.currentTarget.style.borderColor = BORDER; } }}
        >
          <Droplet size={12} />
        </button>

        {/* Opacity Control */}
        <div style={{ display: 'flex', alignItems: 'center', gap: 4, marginRight: 8 }}>
          <span style={{ fontSize: 9, color: MUTED, textTransform: 'uppercase', letterSpacing: '0.05em', fontWeight: 600 }}>Opacity</span>
          <input
            type="range"
            min="0.15" max="1" step="0.05"
            value={opacity}
            onChange={e => onOpacityChange(parseFloat(e.target.value))}
            style={{ width: 45, cursor: 'pointer', accentColor: accent }}
            title="Adjust Window Opacity"
          />
        </div>

        {/* Zoom Control */}
        <div style={{ display: 'flex', alignItems: 'center', gap: 4, marginRight: 12 }}>
          <span style={{ fontSize: 9, color: MUTED, textTransform: 'uppercase', letterSpacing: '0.05em', fontWeight: 600 }}>Zoom</span>
          <button
            onClick={() => onZoomChange(Math.max(0.7, zoom - 0.05))}
            style={{ background: 'transparent', border: `1px solid ${BORDER}`, color: MUTED, width: 16, height: 16, borderRadius: 3, display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer', fontSize: 12, lineHeight: 1 }}
            onMouseEnter={e => { e.currentTarget.style.color = TEXT; e.currentTarget.style.borderColor = TEXT; }}
            onMouseLeave={e => { e.currentTarget.style.color = MUTED;  e.currentTarget.style.borderColor = BORDER; }}
          >
            -
          </button>
          <input
            type="range"
            min="0.7" max="1.35" step="0.05"
            value={zoom}
            onChange={e => onZoomChange(parseFloat(e.target.value))}
            style={{ width: 45, cursor: 'pointer', accentColor: accent }}
            title="Adjust Window Zoom"
          />
          <button
            onClick={() => onZoomChange(Math.min(1.35, zoom + 0.05))}
            style={{ background: 'transparent', border: `1px solid ${BORDER}`, color: MUTED, width: 16, height: 16, borderRadius: 3, display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer', fontSize: 12, lineHeight: 1 }}
            onMouseEnter={e => { e.currentTarget.style.color = TEXT; e.currentTarget.style.borderColor = TEXT; }}
            onMouseLeave={e => { e.currentTarget.style.color = MUTED;  e.currentTarget.style.borderColor = BORDER; }}
          >
            +
          </button>
        </div>

        <kbd style={{
          fontSize: 9, fontFamily: monoFont,
          background: 'rgba(255,255,255,0.04)',
          padding: '2px 6px', borderRadius: 4,
          border: `1px solid rgba(255,255,255,0.07)`,
          color: MUTED, userSelect: 'none', marginRight: 4,
        }}>
          Ctrl+Space
        </kbd>
        <button
          onClick={onClose}
          title="Close (Esc)"
          style={{
            background: 'transparent', border: 'none', cursor: 'pointer',
            color: MUTED, padding: 6, borderRadius: 5, display: 'flex', alignItems: 'center',
            transition: 'background 0.12s, color 0.12s',
          }}
          onMouseEnter={e => { e.currentTarget.style.background = 'rgba(248,113,113,0.12)'; e.currentTarget.style.color = appearance.theme.palette.danger; }}
          onMouseLeave={e => { e.currentTarget.style.background = 'transparent'; e.currentTarget.style.color = MUTED; }}
        >
          <X size={14} />
        </button>
      </div>
    </div>
  );
}

export default App;
