// File system commands for the OverlayTerm file explorer
// Provides: dir listing with metadata, Windows drive enumeration,
// open-with-default-app, open-as-admin (runas), delete, rename, copy.

use serde::{Deserialize, Serialize};
use std::path::Path;

// ─── Data types ───────────────────────────────────────────────────────────────

#[derive(Debug, Serialize, Deserialize, Clone)]
pub struct FileEntry {
    pub name: String,
    pub path: String,
    pub is_dir: bool,
    pub size: u64,
    pub modified: u64, // unix timestamp millis
    pub extension: String,
    pub is_hidden: bool,
    pub is_symlink: bool,
}

#[derive(Debug, Serialize, Deserialize, Clone)]
pub struct DriveInfo {
    pub letter: String,
    pub label: String,
    pub total_bytes: u64,
    pub free_bytes: u64,
    pub drive_type: String,
}

// ─── fs_list_dir ─────────────────────────────────────────────────────────────

#[tauri::command]
pub async fn fs_list_dir(path: String, show_hidden: bool) -> Result<Vec<FileEntry>, String> {
    let dir_path = Path::new(&path);
    if !dir_path.exists() {
        return Err(format!("Path does not exist: {}", path));
    }
    if !dir_path.is_dir() {
        return Err(format!("Path is not a directory: {}", path));
    }

    let read_dir =
        std::fs::read_dir(dir_path).map_err(|e| format!("Failed to read directory: {}", e))?;

    let mut entries: Vec<FileEntry> = Vec::new();
    for entry_result in read_dir {
        let entry = match entry_result {
            Ok(e) => e,
            Err(_) => continue,
        };

        let file_name = entry.file_name();
        let name = file_name.to_string_lossy().to_string();

        // Skip hidden files unless show_hidden is true
        let is_hidden = name.starts_with('.');
        #[cfg(target_os = "windows")]
        let is_hidden = is_hidden || {
            use std::os::windows::fs::MetadataExt;
            entry
                .metadata()
                .map(|m| m.file_attributes() & 0x2 != 0)
                .unwrap_or(false)
        };

        if is_hidden && !show_hidden {
            continue;
        }

        let meta = match entry.metadata() {
            Ok(m) => m,
            Err(_) => continue,
        };

        let modified = meta
            .modified()
            .ok()
            .and_then(|t| t.duration_since(std::time::UNIX_EPOCH).ok())
            .map(|d| d.as_millis() as u64)
            .unwrap_or(0);

        let is_symlink = meta.file_type().is_symlink();
        let is_dir = meta.is_dir();
        let size = if is_dir { 0 } else { meta.len() };

        let entry_path = entry.path().to_string_lossy().to_string();
        let extension = if is_dir {
            String::new()
        } else {
            entry
                .path()
                .extension()
                .map(|e| e.to_string_lossy().to_lowercase())
                .unwrap_or_default()
        };

        entries.push(FileEntry {
            name,
            path: entry_path,
            is_dir,
            size,
            modified,
            extension,
            is_hidden,
            is_symlink,
        });
    }

    // Sort: directories first, then files, alphabetically within each group
    entries.sort_by(|a, b| match (a.is_dir, b.is_dir) {
        (true, false) => std::cmp::Ordering::Less,
        (false, true) => std::cmp::Ordering::Greater,
        _ => a.name.to_lowercase().cmp(&b.name.to_lowercase()),
    });

    Ok(entries)
}

// ─── fs_get_drives (Windows) ──────────────────────────────────────────────────

#[tauri::command]
pub async fn fs_get_drives() -> Result<Vec<DriveInfo>, String> {
    #[cfg(target_os = "windows")]
    {
        let drives = get_windows_drives()?;
        return Ok(drives);
    }

    #[cfg(target_os = "macos")]
    {
        let mut drives = vec![root_drive_info()];
        drives.extend(read_unix_mount_directories("/Volumes"));
        return Ok(drives);
    }

    #[cfg(target_os = "linux")]
    {
        let mut drives = vec![root_drive_info()];
        drives.extend(read_unix_mount_directories("/media"));
        drives.extend(read_unix_mount_directories("/mnt"));
        return Ok(deduplicate_drives(drives));
    }

    #[cfg(not(any(target_os = "windows", target_os = "macos", target_os = "linux")))]
    {
        Ok(vec![root_drive_info()])
    }
}

#[cfg(target_os = "windows")]
fn get_windows_drives() -> Result<Vec<DriveInfo>, String> {
    use std::ffi::OsString;
    use std::os::windows::ffi::OsStringExt;

    // GetLogicalDriveStringsW returns a multi-string (double-null terminated)
    let mut buffer = vec![0u16; 256];
    let len = unsafe {
        windows_sys::Win32::Storage::FileSystem::GetLogicalDriveStringsW(
            buffer.len() as u32,
            buffer.as_mut_ptr(),
        )
    };

    if len == 0 {
        return Err("Failed to enumerate drives".to_string());
    }

    let mut drives = Vec::new();
    let mut start = 0;
    for i in 0..len as usize {
        if buffer[i] == 0 {
            if i > start {
                let drive_str = OsString::from_wide(&buffer[start..i])
                    .to_string_lossy()
                    .to_string();
                let letter = drive_str.trim_end_matches('\\').to_string();

                // Get drive info
                let mut total_bytes: u64 = 0;
                let mut free_bytes: u64 = 0;
                let drive_w: Vec<u16> =
                    drive_str.encode_utf16().chain(std::iter::once(0)).collect();

                unsafe {
                    windows_sys::Win32::Storage::FileSystem::GetDiskFreeSpaceExW(
                        drive_w.as_ptr(),
                        std::ptr::null_mut(),
                        &mut total_bytes as *mut u64,
                        &mut free_bytes as *mut u64,
                    );
                }

                let drive_type = unsafe {
                    let t =
                        windows_sys::Win32::Storage::FileSystem::GetDriveTypeW(drive_w.as_ptr());
                    match t {
                        2 => "removable",
                        3 => "fixed",
                        4 => "remote",
                        5 => "cdrom",
                        6 => "ramdisk",
                        _ => "unknown",
                    }
                };

                // Get volume label
                let mut vol_buf = vec![0u16; 128];
                unsafe {
                    windows_sys::Win32::Storage::FileSystem::GetVolumeInformationW(
                        drive_w.as_ptr(),
                        vol_buf.as_mut_ptr(),
                        vol_buf.len() as u32,
                        std::ptr::null_mut(),
                        std::ptr::null_mut(),
                        std::ptr::null_mut(),
                        std::ptr::null_mut(),
                        0,
                    );
                }
                let label_end = vol_buf.iter().position(|&c| c == 0).unwrap_or(0);
                let label = OsString::from_wide(&vol_buf[..label_end])
                    .to_string_lossy()
                    .to_string();
                let label = if label.is_empty() {
                    letter.clone()
                } else {
                    label
                };

                drives.push(DriveInfo {
                    letter: letter.clone(),
                    label,
                    total_bytes,
                    free_bytes,
                    drive_type: drive_type.to_string(),
                });
            }
            start = i + 1;
        }
    }

    Ok(drives)
}

#[cfg(not(target_os = "windows"))]
fn root_drive_info() -> DriveInfo {
    DriveInfo {
        letter: "/".to_string(),
        label: "Root".to_string(),
        total_bytes: 0,
        free_bytes: 0,
        drive_type: "fixed".to_string(),
    }
}

#[cfg(any(target_os = "macos", target_os = "linux"))]
fn read_unix_mount_directories(base_path: &str) -> Vec<DriveInfo> {
    let path = Path::new(base_path);
    let read_dir = match std::fs::read_dir(path) {
        Ok(entries) => entries,
        Err(_) => return Vec::new(),
    };

    let mut drives = Vec::new();
    for entry in read_dir.flatten() {
        let Ok(file_type) = entry.file_type() else {
            continue;
        };
        if !file_type.is_dir() {
            continue;
        }

        let mount_path = entry.path();
        let label = entry.file_name().to_string_lossy().to_string();
        drives.push(DriveInfo {
            letter: mount_path.to_string_lossy().to_string(),
            label: if label.is_empty() {
                mount_path.to_string_lossy().to_string()
            } else {
                label
            },
            total_bytes: 0,
            free_bytes: 0,
            drive_type: "mounted".to_string(),
        });
    }

    drives.sort_by(|a, b| a.label.to_lowercase().cmp(&b.label.to_lowercase()));
    drives
}

#[cfg(target_os = "linux")]
fn deduplicate_drives(drives: Vec<DriveInfo>) -> Vec<DriveInfo> {
    use std::collections::HashSet;

    let mut seen = HashSet::new();
    let mut unique = Vec::new();
    for drive in drives {
        if seen.insert(drive.letter.clone()) {
            unique.push(drive);
        }
    }
    unique
}

#[cfg(target_os = "macos")]
fn shell_quote_single(value: &str) -> String {
    format!("'{}'", value.replace('\'', r#"'\''"#))
}

#[cfg(target_os = "macos")]
fn escape_applescript_string(value: &str) -> String {
    value.replace('\\', "\\\\").replace('\"', "\\\"")
}

// ─── fs_read_text_file ────────────────────────────────────────────────────────

#[tauri::command]
pub async fn fs_read_text_file(path: String) -> Result<String, String> {
    // Limit file size to 10 MB to avoid hanging Monaco
    let meta = std::fs::metadata(&path).map_err(|e| e.to_string())?;
    if meta.len() > 10 * 1024 * 1024 {
        return Err("File is too large to preview (> 10 MB)".to_string());
    }
    std::fs::read_to_string(&path).map_err(|e| e.to_string())
}

// ─── fs_open_file ─────────────────────────────────────────────────────────────

#[tauri::command]
pub async fn fs_open_file(path: String) -> Result<(), String> {
    #[cfg(target_os = "windows")]
    {
        std::process::Command::new("explorer")
            .arg(&path)
            .spawn()
            .map_err(|e| e.to_string())?;
        return Ok(());
    }
    #[cfg(target_os = "macos")]
    {
        std::process::Command::new("open")
            .arg(&path)
            .spawn()
            .map_err(|e| e.to_string())?;
        return Ok(());
    }
    #[cfg(target_os = "linux")]
    {
        std::process::Command::new("xdg-open")
            .arg(&path)
            .spawn()
            .map_err(|e| e.to_string())?;
        return Ok(());
    }
}

// ─── fs_open_as_admin (Windows runas) ────────────────────────────────────────

#[tauri::command]
pub async fn fs_open_as_admin(path: String) -> Result<(), String> {
    #[cfg(target_os = "windows")]
    {
        use std::ffi::OsStr;
        use std::os::windows::ffi::OsStrExt;

        let verb: Vec<u16> = OsStr::new("runas")
            .encode_wide()
            .chain(std::iter::once(0))
            .collect();
        let file: Vec<u16> = OsStr::new(&path)
            .encode_wide()
            .chain(std::iter::once(0))
            .collect();

        let result = unsafe {
            windows_sys::Win32::UI::Shell::ShellExecuteW(
                std::ptr::null_mut(),
                verb.as_ptr(),
                file.as_ptr(),
                std::ptr::null(),
                std::ptr::null(),
                1, // SW_SHOWNORMAL
            )
        };

        if result as isize <= 32 {
            return Err(format!(
                "ShellExecuteW failed with code: {}",
                result as isize
            ));
        }
        return Ok(());
    }
    #[cfg(target_os = "linux")]
    {
        std::process::Command::new("pkexec")
            .arg(&path)
            .spawn()
            .map_err(|e| e.to_string())?;
        return Ok(());
    }

    #[cfg(target_os = "macos")]
    {
        let shell_command = format!("open {}", shell_quote_single(&path));
        let script = format!(
            "do shell script \"{}\" with administrator privileges",
            escape_applescript_string(&shell_command)
        );

        std::process::Command::new("osascript")
            .arg("-e")
            .arg(script)
            .spawn()
            .map_err(|e| e.to_string())?;
        return Ok(());
    }

    #[cfg(not(any(target_os = "windows", target_os = "linux", target_os = "macos")))]
    {
        Err("Admin elevation is not implemented for this operating system.".to_string())
    }
}

// ─── fs_reveal_in_explorer ────────────────────────────────────────────────────

#[tauri::command]
pub async fn fs_reveal_in_explorer(path: String) -> Result<(), String> {
    #[cfg(target_os = "windows")]
    {
        std::process::Command::new("explorer")
            .arg("/select,")
            .arg(&path)
            .spawn()
            .map_err(|e| e.to_string())?;
        return Ok(());
    }
    #[cfg(target_os = "macos")]
    {
        std::process::Command::new("open")
            .arg("-R")
            .arg(&path)
            .spawn()
            .map_err(|e| e.to_string())?;
        return Ok(());
    }
    #[cfg(target_os = "linux")]
    {
        std::process::Command::new("xdg-open")
            .arg(
                std::path::Path::new(&path)
                    .parent()
                    .unwrap_or(std::path::Path::new("/")),
            )
            .spawn()
            .map_err(|e| e.to_string())?;
        return Ok(());
    }
}

// ─── fs_delete ────────────────────────────────────────────────────────────────

#[tauri::command]
pub async fn fs_delete(path: String, recursive: bool) -> Result<(), String> {
    let p = Path::new(&path);
    if p.is_dir() {
        if recursive {
            std::fs::remove_dir_all(p).map_err(|e| e.to_string())
        } else {
            std::fs::remove_dir(p).map_err(|e| e.to_string())
        }
    } else {
        std::fs::remove_file(p).map_err(|e| e.to_string())
    }
}

// ─── fs_rename ────────────────────────────────────────────────────────────────

#[tauri::command]
pub async fn fs_rename(old_path: String, new_path: String) -> Result<(), String> {
    std::fs::rename(&old_path, &new_path).map_err(|e| e.to_string())
}

// ─── fs_copy ─────────────────────────────────────────────────────────────────

#[tauri::command]
pub async fn fs_copy(src: String, dst: String) -> Result<(), String> {
    let src_path = Path::new(&src);
    if src_path.is_dir() {
        copy_dir_all(src_path, Path::new(&dst)).map_err(|e| e.to_string())
    } else {
        std::fs::copy(&src, &dst)
            .map(|_| ())
            .map_err(|e| e.to_string())
    }
}

fn copy_dir_all(src: &Path, dst: &Path) -> std::io::Result<()> {
    std::fs::create_dir_all(dst)?;
    for entry in std::fs::read_dir(src)? {
        let entry = entry?;
        let ty = entry.file_type()?;
        let dst_entry = dst.join(entry.file_name());
        if ty.is_dir() {
            copy_dir_all(&entry.path(), &dst_entry)?;
        } else {
            std::fs::copy(entry.path(), dst_entry)?;
        }
    }
    Ok(())
}

// ─── fs_create_dir ────────────────────────────────────────────────────────────

#[tauri::command]
pub async fn fs_create_dir(path: String) -> Result<(), String> {
    std::fs::create_dir_all(&path).map_err(|e| e.to_string())
}

// ─── fs_write_file ────────────────────────────────────────────────────────────

#[tauri::command]
pub async fn fs_write_file(path: String, content: String) -> Result<(), String> {
    if let Some(parent) = std::path::Path::new(&path).parent() {
        std::fs::create_dir_all(parent).map_err(|e| e.to_string())?;
    }
    std::fs::write(&path, content.as_bytes()).map_err(|e| e.to_string())
}

// ─── git_exec ─────────────────────────────────────────────────────────────────
// Executes a git command in the specified directory and returns stdout (or stderr on failure)
#[tauri::command]
pub async fn git_exec(repo_path: String, args: Vec<String>) -> Result<String, String> {
    #[cfg(target_os = "windows")]
    use std::os::windows::process::CommandExt;
    use std::process::Command;

    let mut cmd = Command::new("git");
    cmd.current_dir(&repo_path).args(&args);

    #[cfg(target_os = "windows")]
    {
        const CREATE_NO_WINDOW: u32 = 0x08000000;
        cmd.creation_flags(CREATE_NO_WINDOW);
    }

    let output = cmd
        .output()
        .map_err(|e| format!("Failed to run git: {}", e))?;

    if output.status.success() {
        Ok(String::from_utf8_lossy(&output.stdout).to_string())
    } else {
        Err(String::from_utf8_lossy(&output.stderr).to_string())
    }
}

// ─── fs_read_file_base64 ─────────────────────────────────────────────────────
// Returns the file as a data-URI so the frontend can render it without
// needing the asset:// protocol (which requires allow-listed paths).

#[tauri::command]
pub async fn fs_read_file_base64(path: String) -> Result<String, String> {
    use std::io::Read;
    let meta = std::fs::metadata(&path).map_err(|e| e.to_string())?;
    // Cap at 50 MB — large enough for most images
    if meta.len() > 50 * 1024 * 1024 {
        return Err("File is too large to preview (> 50 MB)".to_string());
    }
    let mut file = std::fs::File::open(&path).map_err(|e| e.to_string())?;
    let mut buf = Vec::new();
    file.read_to_end(&mut buf).map_err(|e| e.to_string())?;

    // Determine MIME type from extension
    let ext = std::path::Path::new(&path)
        .extension()
        .map(|e| e.to_string_lossy().to_lowercase())
        .unwrap_or_default();
    let mime = match ext.as_str() {
        "png" => "image/png",
        "jpg" | "jpeg" => "image/jpeg",
        "gif" => "image/gif",
        "webp" => "image/webp",
        "bmp" => "image/bmp",
        "ico" => "image/x-icon",
        "svg" => "image/svg+xml",
        "tiff" | "tif" => "image/tiff",
        "avif" => "image/avif",
        _ => "application/octet-stream",
    };

    // Use a simple base64 encoder (no external crate needed — stdlib in Rust is fine)
    let b64 = base64_encode(&buf);
    Ok(format!("data:{};base64,{}", mime, b64))
}

/// Minimal, allocation-efficient base64 encoder (RFC 4648, no padding issues)
fn base64_encode(input: &[u8]) -> String {
    const CHARS: &[u8] = b"ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
    let mut out = String::with_capacity((input.len() + 2) / 3 * 4);
    for chunk in input.chunks(3) {
        let b0 = chunk[0] as usize;
        let b1 = if chunk.len() > 1 {
            chunk[1] as usize
        } else {
            0
        };
        let b2 = if chunk.len() > 2 {
            chunk[2] as usize
        } else {
            0
        };
        out.push(CHARS[b0 >> 2] as char);
        out.push(CHARS[((b0 & 3) << 4) | (b1 >> 4)] as char);
        out.push(if chunk.len() > 1 {
            CHARS[((b1 & 15) << 2) | (b2 >> 6)] as char
        } else {
            '='
        });
        out.push(if chunk.len() > 2 {
            CHARS[b2 & 63] as char
        } else {
            '='
        });
    }
    out
}

// ─── fs_get_home_dir ──────────────────────────────────────────────────────────

#[tauri::command]
pub async fn fs_get_home_dir() -> Result<String, String> {
    dirs::home_dir()
        .map(|p| p.to_string_lossy().to_string())
        .ok_or_else(|| "Could not determine home directory".to_string())
}

// ─── Unit Tests ───────────────────────────────────────────────────────────────
// Run with: cargo test -p tauri-app

#[cfg(test)]
mod tests {
    use super::*;
    use std::fs;
    use std::path::PathBuf;
    use tempfile::TempDir;

    // ── helper: build a FileEntry directly (bypasses async/Tauri) ──────────────

    fn make_entry(name: &str, is_dir: bool, size: u64, ext: &str, hidden: bool) -> FileEntry {
        FileEntry {
            name: name.to_string(),
            path: format!("C:\\test\\{}", name),
            is_dir,
            size,
            modified: 1_700_000_000_000,
            extension: ext.to_string(),
            is_hidden: hidden,
            is_symlink: false,
        }
    }

    // ── Sorting logic (extracted so we can test it without async/Tauri) ─────────

    fn sort_entries(entries: &mut Vec<FileEntry>) {
        entries.sort_by(|a, b| match (a.is_dir, b.is_dir) {
            (true, false) => std::cmp::Ordering::Less,
            (false, true) => std::cmp::Ordering::Greater,
            _ => a.name.to_lowercase().cmp(&b.name.to_lowercase()),
        });
    }

    // ── Extension extraction helper ─────────────────────────────────────────────

    fn get_extension(path: &str) -> String {
        std::path::Path::new(path)
            .extension()
            .map(|e| e.to_string_lossy().to_lowercase())
            .unwrap_or_default()
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // Sorting
    // ═══════════════════════════════════════════════════════════════════════════

    #[test]
    fn sort_dirs_before_files() {
        let mut entries = vec![
            make_entry("zebra.txt", false, 100, "txt", false),
            make_entry("alpha", true, 0, "", false),
            make_entry("mango.rs", false, 200, "rs", false),
            make_entry("beta", true, 0, "", false),
        ];
        sort_entries(&mut entries);

        // First two must be directories
        assert!(
            entries[0].is_dir,
            "entry[0] should be dir, got '{}'",
            entries[0].name
        );
        assert!(
            entries[1].is_dir,
            "entry[1] should be dir, got '{}'",
            entries[1].name
        );
        // Last two must be files
        assert!(
            !entries[2].is_dir,
            "entry[2] should be file, got '{}'",
            entries[2].name
        );
        assert!(
            !entries[3].is_dir,
            "entry[3] should be file, got '{}'",
            entries[3].name
        );
    }

    #[test]
    fn sort_dirs_alphabetically() {
        let mut entries = vec![
            make_entry("Zeta", true, 0, "", false),
            make_entry("alpha", true, 0, "", false),
            make_entry("Beta", true, 0, "", false),
        ];
        sort_entries(&mut entries);
        assert_eq!(entries[0].name, "alpha");
        assert_eq!(entries[1].name, "Beta");
        assert_eq!(entries[2].name, "Zeta");
    }

    #[test]
    fn sort_files_alphabetically() {
        let mut entries = vec![
            make_entry("zebra.txt", false, 10, "txt", false),
            make_entry("Apple.rs", false, 20, "rs", false),
            make_entry("mango.json", false, 30, "json", false),
        ];
        sort_entries(&mut entries);
        assert_eq!(entries[0].name, "Apple.rs");
        assert_eq!(entries[1].name, "mango.json");
        assert_eq!(entries[2].name, "zebra.txt");
    }

    #[test]
    fn sort_empty_list_is_noop() {
        let mut entries: Vec<FileEntry> = vec![];
        sort_entries(&mut entries);
        assert!(entries.is_empty());
    }

    #[test]
    fn sort_single_entry_unchanged() {
        let mut entries = vec![make_entry("lone.txt", false, 1, "txt", false)];
        sort_entries(&mut entries);
        assert_eq!(entries.len(), 1);
        assert_eq!(entries[0].name, "lone.txt");
    }

    #[test]
    fn sort_case_insensitive_mixed() {
        let mut entries = vec![
            make_entry("ZZZ", true, 0, "", false),
            make_entry("aaa", true, 0, "", false),
            make_entry("MMM", true, 0, "", false),
        ];
        sort_entries(&mut entries);
        assert_eq!(entries[0].name, "aaa");
        assert_eq!(entries[1].name, "MMM");
        assert_eq!(entries[2].name, "ZZZ");
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // Extension extraction
    // ═══════════════════════════════════════════════════════════════════════════

    #[test]
    fn extension_simple() {
        assert_eq!(get_extension("file.txt"), "txt");
        assert_eq!(get_extension("file.RS"), "rs"); // lowercased
        assert_eq!(get_extension("file.JSON"), "json");
    }

    #[test]
    fn extension_multi_dot() {
        // Only the last extension
        assert_eq!(get_extension("archive.tar.gz"), "gz");
        assert_eq!(get_extension("vite.config.ts"), "ts");
    }

    #[test]
    fn extension_no_extension() {
        assert_eq!(get_extension("Makefile"), "");
        assert_eq!(get_extension("README"), "");
    }

    #[test]
    fn extension_hidden_unix_file() {
        // ".gitignore" has no extension (the name IS the dot-file)
        assert_eq!(get_extension(".gitignore"), "");
        // ".env" has no extension either
        assert_eq!(get_extension(".env"), "");
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // FileEntry serialisation (snapshot of struct field types)
    // ═══════════════════════════════════════════════════════════════════════════

    #[test]
    fn file_entry_serialises_to_json() {
        let entry = make_entry("test.ts", false, 2048, "ts", false);
        let json = serde_json::to_string(&entry).expect("serialisation failed");

        // Check all required fields are present in the JSON blob
        for field in &[
            "name",
            "path",
            "is_dir",
            "size",
            "modified",
            "extension",
            "is_hidden",
            "is_symlink",
        ] {
            assert!(
                json.contains(field),
                "missing field '{}' in JSON: {}",
                field,
                json
            );
        }
        assert!(json.contains("\"name\":\"test.ts\""), "name mismatch");
        assert!(json.contains("\"size\":2048"), "size mismatch");
        assert!(json.contains("\"extension\":\"ts\""), "extension mismatch");
        assert!(json.contains("\"is_dir\":false"), "is_dir mismatch");
    }

    #[test]
    fn drive_info_serialises_to_json() {
        let drive = DriveInfo {
            letter: "C:".to_string(),
            label: "OS".to_string(),
            total_bytes: 512_000_000_000,
            free_bytes: 128_000_000_000,
            drive_type: "fixed".to_string(),
        };
        let json = serde_json::to_string(&drive).expect("serialisation failed");
        assert!(json.contains("\"letter\":\"C:\""));
        assert!(json.contains("\"drive_type\":\"fixed\""));
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // Real filesystem integration tests (uses tempdir — always safe)
    // ═══════════════════════════════════════════════════════════════════════════

    fn tmp_dir() -> TempDir {
        tempfile::tempdir().expect("failed to create tempdir")
    }

    #[tokio::test]
    async fn list_dir_returns_files_and_dirs() {
        let dir = tmp_dir();
        let dir_path = dir.path();

        // Create a sub-directory and two files
        fs::create_dir(dir_path.join("subdir")).unwrap();
        fs::write(dir_path.join("hello.txt"), b"hello").unwrap();
        fs::write(dir_path.join("data.json"), b"{}").unwrap();

        let result = fs_list_dir(dir_path.to_string_lossy().into(), false).await;
        let entries = result.expect("fs_list_dir failed");

        assert!(
            entries.len() >= 3,
            "expected at least 3 entries, got {}",
            entries.len()
        );

        let subdirs: Vec<_> = entries.iter().filter(|e| e.is_dir).collect();
        let files: Vec<_> = entries.iter().filter(|e| !e.is_dir).collect();
        assert!(!subdirs.is_empty(), "no directories found");
        assert!(files.len() >= 2, "expected at least 2 files");
    }

    #[tokio::test]
    async fn list_dir_dirs_come_first() {
        let dir = tmp_dir();
        fs::create_dir(dir.path().join("zzz_dir")).unwrap();
        fs::write(dir.path().join("aaa.txt"), b"a").unwrap();

        let entries = fs_list_dir(dir.path().to_string_lossy().into(), false)
            .await
            .expect("fs_list_dir failed");

        // The directory "zzz_dir" should appear BEFORE "aaa.txt" despite 'z' > 'a'
        let first = &entries[0];
        assert!(
            first.is_dir,
            "first entry should be a directory (dirs-first sort)"
        );
    }

    #[tokio::test]
    async fn list_dir_hides_hidden_files_by_default() {
        let dir = tmp_dir();
        fs::write(dir.path().join(".hidden"), b"secret").unwrap();
        fs::write(dir.path().join("visible.txt"), b"public").unwrap();

        let entries_no_hidden = fs_list_dir(dir.path().to_string_lossy().into(), false)
            .await
            .expect("fs_list_dir failed");

        let has_hidden = entries_no_hidden.iter().any(|e| e.name.starts_with('.'));
        assert!(
            !has_hidden,
            "hidden file should not appear when show_hidden=false"
        );
    }

    #[tokio::test]
    async fn list_dir_shows_hidden_files_when_requested() {
        let dir = tmp_dir();
        fs::write(dir.path().join(".hidden"), b"secret").unwrap();
        fs::write(dir.path().join("visible.txt"), b"public").unwrap();

        let entries_with_hidden = fs_list_dir(dir.path().to_string_lossy().into(), true)
            .await
            .expect("fs_list_dir failed");

        let has_hidden = entries_with_hidden.iter().any(|e| e.name.starts_with('.'));
        assert!(
            has_hidden,
            "hidden file should appear when show_hidden=true"
        );
    }

    #[tokio::test]
    async fn list_dir_fails_for_nonexistent_path() {
        let result = fs_list_dir("C:\\nonexistent\\path\\xyz_abc".to_string(), false).await;
        assert!(result.is_err(), "expected Err for nonexistent path");
        let msg = result.unwrap_err();
        assert!(
            msg.contains("not exist") || msg.contains("exist"),
            "error message: {}",
            msg
        );
    }

    #[tokio::test]
    async fn list_dir_fails_for_file_path() {
        let dir = tmp_dir();
        let file_path = dir.path().join("some.txt");
        fs::write(&file_path, b"data").unwrap();

        let result = fs_list_dir(file_path.to_string_lossy().into(), false).await;
        assert!(
            result.is_err(),
            "expected Err when path is a file, not a dir"
        );
    }

    #[tokio::test]
    async fn read_text_file_reads_content() {
        let dir = tmp_dir();
        let file_path = dir.path().join("data.toml");
        let content = "[package]\nname = \"test\"";
        fs::write(&file_path, content).unwrap();

        let result = fs_read_text_file(file_path.to_string_lossy().into()).await;
        assert!(result.is_ok(), "expected Ok, got {:?}", result);
        assert_eq!(result.unwrap(), content);
    }

    #[tokio::test]
    async fn read_text_file_rejects_large_file() {
        let dir = tmp_dir();
        let path = dir.path().join("big.bin");
        // Create a file just over 10 MB
        let big_data = vec![0u8; 10 * 1024 * 1024 + 1];
        fs::write(&path, &big_data).unwrap();

        let result = fs_read_text_file(path.to_string_lossy().into()).await;
        assert!(result.is_err(), "expected Err for file > 10 MB");
        assert!(
            result.unwrap_err().contains("too large"),
            "wrong error message"
        );
    }

    #[tokio::test]
    async fn create_dir_creates_nested_directories() {
        let dir = tmp_dir();
        let new_path = dir.path().join("a").join("b").join("c");
        let result = fs_create_dir(new_path.to_string_lossy().into()).await;
        assert!(result.is_ok(), "fs_create_dir failed: {:?}", result);
        assert!(new_path.exists(), "directory was not created");
        assert!(new_path.is_dir(), "path is not a directory");
    }

    #[tokio::test]
    async fn rename_renames_file() {
        let dir = tmp_dir();
        let src = dir.path().join("old.txt");
        let dst = dir.path().join("new.txt");
        fs::write(&src, b"content").unwrap();

        let result = fs_rename(src.to_string_lossy().into(), dst.to_string_lossy().into()).await;

        assert!(result.is_ok(), "fs_rename failed: {:?}", result);
        assert!(!src.exists(), "source should no longer exist");
        assert!(dst.exists(), "destination should exist");
        assert_eq!(fs::read(&dst).unwrap(), b"content");
    }

    #[tokio::test]
    async fn copy_copies_single_file() {
        let dir = tmp_dir();
        let src = dir.path().join("original.txt");
        let dst = dir.path().join("copy.txt");
        fs::write(&src, b"hello world").unwrap();

        let result = fs_copy(src.to_string_lossy().into(), dst.to_string_lossy().into()).await;

        assert!(result.is_ok(), "fs_copy failed: {:?}", result);
        assert!(src.exists(), "source should still exist after copy");
        assert!(dst.exists(), "destination should exist");
        assert_eq!(fs::read(&dst).unwrap(), b"hello world");
    }

    #[tokio::test]
    async fn copy_copies_directory_recursively() {
        let dir = tmp_dir();
        let src_dir = dir.path().join("src_folder");
        let dst_dir = dir.path().join("dst_folder");

        fs::create_dir(&src_dir).unwrap();
        fs::write(src_dir.join("file1.txt"), b"one").unwrap();
        fs::create_dir(src_dir.join("nested")).unwrap();
        fs::write(src_dir.join("nested").join("file2.txt"), b"two").unwrap();

        let result = fs_copy(
            src_dir.to_string_lossy().into(),
            dst_dir.to_string_lossy().into(),
        )
        .await;

        assert!(result.is_ok(), "recursive copy failed: {:?}", result);
        assert!(
            dst_dir.join("file1.txt").exists(),
            "file1.txt missing in dst"
        );
        assert!(
            dst_dir.join("nested").join("file2.txt").exists(),
            "nested/file2.txt missing"
        );
        assert_eq!(
            fs::read(dst_dir.join("nested").join("file2.txt")).unwrap(),
            b"two"
        );
    }

    #[tokio::test]
    async fn delete_removes_a_file() {
        let dir = tmp_dir();
        let file = dir.path().join("gone.txt");
        fs::write(&file, b"bye").unwrap();

        let result = fs_delete(file.to_string_lossy().into(), false).await;
        assert!(result.is_ok(), "delete failed: {:?}", result);
        assert!(!file.exists(), "file should be gone");
    }

    #[tokio::test]
    async fn delete_removes_directory_when_recursive() {
        let dir = tmp_dir();
        let sub = dir.path().join("to_delete");
        fs::create_dir(&sub).unwrap();
        fs::write(sub.join("inner.txt"), b"data").unwrap();

        let result = fs_delete(sub.to_string_lossy().into(), true).await;
        assert!(result.is_ok(), "recursive delete failed: {:?}", result);
        assert!(!sub.exists(), "directory should be gone");
    }

    #[tokio::test]
    async fn delete_fails_non_empty_dir_without_recursive() {
        let dir = tmp_dir();
        let sub = dir.path().join("non_empty");
        fs::create_dir(&sub).unwrap();
        fs::write(sub.join("file.txt"), b"data").unwrap();

        let result = fs_delete(sub.to_string_lossy().into(), false).await;
        assert!(
            result.is_err(),
            "expected Err when deleting non-empty dir without recursive"
        );
    }

    #[tokio::test]
    async fn get_home_dir_returns_a_path() {
        let result = fs_get_home_dir().await;
        assert!(result.is_ok(), "fs_get_home_dir failed: {:?}", result);
        let home = result.unwrap();
        assert!(!home.is_empty(), "home dir should not be empty");
        // Should be an absolute path
        let p = std::path::Path::new(&home);
        assert!(p.is_absolute(), "home dir '{}' should be absolute", home);
    }
}
