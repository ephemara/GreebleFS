import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { invoke } from '@tauri-apps/api/core';
import * as TauriEvent from '@tauri-apps/api/event';
import * as TauriWindow from '@tauri-apps/api/window';
import * as TauriFs from '@tauri-apps/plugin-fs';
import { Blocks, FolderOpen, LoaderCircle, Puzzle, RefreshCw, TriangleAlert } from 'lucide-react';
import { pluginSystemConfig } from '../config/plugins';
import type { ResolvedOverlayAppearance } from '../config/appearance';
import type { PanelCatalogEntry } from '../panels/panelRegistry';
import {
  isFrontendPluginFile,
  loadPluginFromSource,
  type LoadedOverlayPlugin,
  type OverlayPluginApi,
  type OverlayPluginContext,
  type PluginBackendResult,
  type PluginFileEntry,
} from './pluginRuntime';

const PANEL = 'var(--overlay-bg-panel)';
const PANEL_ALT = 'var(--overlay-bg-panel-alt)';
const BORDER = 'var(--overlay-border)';
const MUTED = 'var(--overlay-text-muted)';
const TEXT = 'var(--overlay-text-primary)';

async function ensureDir(path: string): Promise<void> {
  try {
    await invoke('fs_list_dir', { path, showHidden: false });
  } catch {
    await invoke('fs_create_dir', { path });
  }
}

export function PluginsManager({
  appearance,
  builtInCatalog = [],
}: {
  appearance?: ResolvedOverlayAppearance;
  builtInCatalog?: PanelCatalogEntry[];
}) {
  const accent = appearance?.theme.palette.accent ?? 'var(--overlay-accent)';
  const [plugins, setPlugins] = useState<LoadedOverlayPlugin[]>([]);
  const [selectedPluginId, setSelectedPluginId] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const signatureRef = useRef<string>('');

  const openPluginsFolder = useCallback(async () => {
    await ensureDir(pluginSystemConfig.pluginsDirectory);
    await invoke('fs_open_file', { path: pluginSystemConfig.pluginsDirectory });
  }, []);

  const createPluginApi = useCallback((plugin: OverlayPluginContext): OverlayPluginApi => ({
    invoke,
    event: TauriEvent,
    window: TauriWindow,
    fs: TauriFs,
    refreshPlugins: async () => {
      await refreshPlugins(true);
    },
    openPluginsFolder,
    runBackend: async (entry, args = []) => invoke<PluginBackendResult>('plugin_run_backend', {
      pluginsRoot: pluginSystemConfig.pluginsDirectory,
      pluginId: plugin.id,
      entry,
      args,
    }),
  }), [openPluginsFolder]);

  const refreshPlugins = useCallback(async (force = false) => {
    if (force) {
      signatureRef.current = '';
    }

    setIsLoading(prev => prev && !force);
    setError(null);
    try {
      await ensureDir(pluginSystemConfig.pluginsDirectory);
      const listed = await invoke<PluginFileEntry[]>('fs_list_dir', {
        path: pluginSystemConfig.pluginsDirectory,
        showHidden: false,
      });
      const files = listed.filter(isFrontendPluginFile).sort((a, b) => a.name.localeCompare(b.name));
      const nextSignature = files.map(file => `${file.path}:${file.modified}`).join('|');

      if (!force && nextSignature === signatureRef.current) {
        setIsLoading(false);
        return;
      }

      signatureRef.current = nextSignature;
      const loaded = await Promise.all(files.map(async file => {
        const source = await invoke<string>('fs_read_text_file', { path: file.path });
        return loadPluginFromSource(source, file, createPluginApi);
      }));

      setPlugins(loaded);
      setSelectedPluginId(current => {
        if (current && loaded.some(plugin => plugin.id === current)) {
          return current;
        }
        return loaded[0]?.id ?? null;
      });
    } catch (err) {
      setError(String(err));
      setPlugins([]);
      setSelectedPluginId(null);
    } finally {
      setIsLoading(false);
    }
  }, [createPluginApi]);

  useEffect(() => {
    refreshPlugins(true);
  }, [refreshPlugins]);

  useEffect(() => {
    const interval = window.setInterval(() => {
      refreshPlugins();
    }, pluginSystemConfig.scanIntervalMs);

    return () => window.clearInterval(interval);
  }, [refreshPlugins]);

  const selectedPlugin = useMemo(
    () => plugins.find(plugin => plugin.id === selectedPluginId) ?? null,
    [plugins, selectedPluginId],
  );

  return (
    <div style={{ display: 'flex', flex: 1, minHeight: 0, background: 'var(--overlay-bg-app)', color: TEXT, fontFamily: 'var(--overlay-font-ui)' }}>
      <aside style={{
        width: 280,
        borderRight: `1px solid ${BORDER}`,
        background: PANEL,
        display: 'flex',
        flexDirection: 'column',
        minHeight: 0,
      }}
      >
        <div style={{ padding: '14px 16px', borderBottom: `1px solid ${BORDER}` }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
            <div style={{
              width: 28,
              height: 28,
              borderRadius: 8,
              background: `${accent}1f`,
              border: `1px solid ${accent}66`,
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
            }}
            >
              <Puzzle size={15} style={{ color: accent }} />
            </div>
            <div>
              <div style={{ fontSize: 15, fontWeight: 700, color: TEXT }}>Plugins</div>
              <div style={{ fontSize: 11, color: MUTED }}>Drop a TSX file into the plugins folder.</div>
            </div>
          </div>

          <div style={{ display: 'flex', gap: 8, marginTop: 12 }}>
            <button onClick={() => refreshPlugins(true)} style={toolbarButton(accent, false)}>
              <RefreshCw size={14} />
              Refresh
            </button>
            <button onClick={openPluginsFolder} style={toolbarButton(accent, true)}>
              <FolderOpen size={14} />
              Open Folder
            </button>
          </div>
        </div>

        <div style={{ flex: 1, minHeight: 0, overflowY: 'auto', padding: 10 }}>
          {builtInCatalog.length > 0 && (
            <div style={{ marginBottom: 14 }}>
              <div style={{ padding: '4px 8px 10px', fontSize: 11, color: MUTED, textTransform: 'uppercase', letterSpacing: '0.08em' }}>
                Built-in Panel Plugins
              </div>
              {builtInCatalog.map(panel => (
                <div
                  key={panel.id}
                  style={{
                    padding: '10px 12px',
                    borderRadius: 12,
                    border: `1px solid ${panel.example ? `${accent}66` : BORDER}`,
                    background: panel.example ? `${accent}12` : 'transparent',
                    marginBottom: 8,
                  }}
                >
                  <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 8 }}>
                    <div style={{ fontSize: 12, fontWeight: 700, color: TEXT }}>{panel.label}</div>
                    <div style={{
                      fontSize: 10,
                      fontWeight: 700,
                      color: panel.example ? accent : MUTED,
                      textTransform: 'uppercase',
                      letterSpacing: '0.08em',
                    }}
                    >
                      {panel.example ? 'Example' : 'Built-in'}
                    </div>
                  </div>
                  <div style={{ marginTop: 5, fontSize: 11, color: MUTED, lineHeight: 1.5 }}>
                    {panel.description}
                  </div>
                </div>
              ))}
            </div>
          )}

          {builtInCatalog.length > 0 && (
            <div style={{ padding: '4px 8px 10px', fontSize: 11, color: MUTED, textTransform: 'uppercase', letterSpacing: '0.08em' }}>
              Folder Plugins
            </div>
          )}

          {plugins.length === 0 && !isLoading ? (
            <div style={{
              padding: 14,
              borderRadius: 12,
              border: `1px dashed ${accent}55`,
              background: `${accent}0d`,
              color: MUTED,
              fontSize: 12,
              lineHeight: 1.55,
            }}
            >
              No plugins found in `{pluginSystemConfig.pluginsDirectory}` yet.
            </div>
          ) : (
            plugins.map(plugin => {
              const isSelected = plugin.id === selectedPluginId;
              return (
                <button
                  key={`${plugin.id}-${plugin.modified}`}
                  onClick={() => setSelectedPluginId(plugin.id)}
                  style={{
                    width: '100%',
                    textAlign: 'left',
                    padding: '12px 12px',
                    borderRadius: 12,
                    border: `1px solid ${isSelected ? `${accent}88` : BORDER}`,
                    background: isSelected ? `${accent}17` : 'transparent',
                    color: TEXT,
                    cursor: 'pointer',
                    marginBottom: 8,
                  }}
                >
                  <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 8 }}>
                    <div style={{ fontSize: 12, fontWeight: 700 }}>{plugin.name}</div>
                    {plugin.error && <TriangleAlert size={13} style={{ color: '#f59e0b' }} />}
                  </div>
                  <div style={{ marginTop: 5, fontSize: 11, color: MUTED }}>
                    {plugin.error ? 'Load error' : 'Ready'}
                  </div>
                </button>
              );
            })
          )}
        </div>
      </aside>

      <main style={{ flex: 1, minWidth: 0, minHeight: 0, display: 'flex', flexDirection: 'column' }}>
        <div style={{
          padding: '14px 16px',
          borderBottom: `1px solid ${BORDER}`,
          background: PANEL_ALT,
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'space-between',
          gap: 12,
        }}
        >
          <div>
            <div style={{ fontSize: 15, fontWeight: 700, color: TEXT }}>
              {selectedPlugin?.name ?? 'Plugin Workspace'}
            </div>
            <div style={{ fontSize: 11, color: MUTED, marginTop: 4 }}>
              {selectedPlugin?.filePath ?? pluginSystemConfig.pluginsDirectory}
            </div>
          </div>

          {isLoading && (
            <div style={{ display: 'flex', alignItems: 'center', gap: 8, fontSize: 12, color: MUTED }}>
              <LoaderCircle size={14} className="animate-spin" />
              Loading plugins...
            </div>
          )}
        </div>

        {error && (
          <div style={{ padding: '10px 16px', fontSize: 12, color: 'var(--overlay-danger)', borderBottom: `1px solid ${BORDER}`, background: 'color-mix(in srgb, var(--overlay-danger) 18%, transparent)' }}>
            {error}
          </div>
        )}

        <div style={{ flex: 1, minHeight: 0, overflow: 'auto', padding: 16 }}>
          {!selectedPlugin ? (
            <EmptyPluginsState accent={accent} onOpenFolder={openPluginsFolder} />
          ) : selectedPlugin.error ? (
            <PluginErrorPanel plugin={selectedPlugin} />
          ) : selectedPlugin.component ? (
            <PluginErrorBoundary pluginName={selectedPlugin.name}>
              <selectedPlugin.component
                plugin={selectedPlugin}
                api={createPluginApi(selectedPlugin)}
                appearance={{
                  theme: appearance?.theme ?? ({
                    id: 'operator',
                    name: 'Operator',
                    palette: {} as never,
                    effects: {} as never,
                    xterm: {} as never,
                  }),
                  fonts: appearance?.fonts ?? {
                    ui: 'var(--overlay-font-ui)',
                    mono: 'var(--overlay-font-mono)',
                  },
                  cssVars: appearance?.cssVars ?? {},
                }}
              />
            </PluginErrorBoundary>
          ) : (
            <PluginErrorPanel plugin={selectedPlugin} />
          )}
        </div>
      </main>
    </div>
  );
}

function EmptyPluginsState({ accent, onOpenFolder }: { accent: string; onOpenFolder: () => Promise<void> }) {
  return (
    <div style={{
      minHeight: 280,
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center',
      justifyContent: 'center',
      gap: 14,
      borderRadius: 18,
      border: `1px dashed ${accent}55`,
      background: `${accent}0d`,
      color: TEXT,
      textAlign: 'center',
      padding: 24,
    }}
    >
      <Blocks size={34} style={{ color: accent }} />
      <div style={{ fontSize: 16, fontWeight: 700 }}>Drop-in plugins are ready</div>
      <div style={{ fontSize: 12, color: MUTED, maxWidth: 520, lineHeight: 1.6 }}>
        Put a self-contained TSX file into `{pluginSystemConfig.pluginsDirectory}` and this tab will pick it up automatically.
        If a plugin needs its own native helper, place it in `{pluginSystemConfig.pluginsDirectory}\plugin-name\backend`.
      </div>
      <button onClick={() => void onOpenFolder()} style={toolbarButton(accent, true)}>
        <FolderOpen size={14} />
        Open Plugins Folder
      </button>
    </div>
  );
}

function PluginErrorPanel({ plugin }: { plugin: LoadedOverlayPlugin }) {
  return (
    <div style={{
      borderRadius: 18,
      border: '1px solid color-mix(in srgb, var(--overlay-warning) 45%, transparent)',
      background: 'color-mix(in srgb, var(--overlay-warning) 14%, transparent)',
      padding: 18,
      color: TEXT,
    }}
    >
      <div style={{ display: 'flex', alignItems: 'center', gap: 10, fontSize: 15, fontWeight: 700 }}>
        <TriangleAlert size={16} style={{ color: 'var(--overlay-warning)' }} />
        {plugin.name} failed to load
      </div>
      <pre style={{
        marginTop: 12,
        padding: 12,
        borderRadius: 12,
        background: 'color-mix(in srgb, var(--overlay-bg-app) 72%, black)',
        color: 'var(--overlay-warning)',
        whiteSpace: 'pre-wrap',
        fontSize: 12,
        lineHeight: 1.5,
        border: `1px solid rgba(245,158,11,0.2)`,
      }}
      >
        {plugin.error}
      </pre>
      <div style={{ marginTop: 10, fontSize: 11, color: MUTED }}>
        Imports are intentionally restricted to React, `lucide-react`, selected Tauri modules, and `overlayterm-plugin`.
      </div>
    </div>
  );
}

function toolbarButton(accent: string, primary: boolean): React.CSSProperties {
  return {
    display: 'inline-flex',
    alignItems: 'center',
    gap: 8,
    borderRadius: 10,
    padding: '8px 12px',
    border: `1px solid ${primary ? accent : BORDER}`,
    background: primary ? `${accent}22` : 'var(--overlay-bg-card)',
    color: primary ? 'var(--overlay-accent-contrast)' : 'var(--overlay-text-secondary)',
    cursor: 'pointer',
    fontSize: 12,
    fontWeight: 600,
  };
}

class PluginErrorBoundary extends React.Component<
  { children: React.ReactNode; pluginName: string },
  { error: string | null }
> {
  constructor(props: { children: React.ReactNode; pluginName: string }) {
    super(props);
    this.state = { error: null };
  }

  static getDerivedStateFromError(error: unknown) {
    return { error: String(error) };
  }

  override componentDidUpdate(prevProps: { pluginName: string }) {
    if (prevProps.pluginName !== this.props.pluginName && this.state.error) {
      this.setState({ error: null });
    }
  }

  override render() {
    if (!this.state.error) {
      return this.props.children;
    }

    return (
      <div style={{
        borderRadius: 18,
        border: '1px solid color-mix(in srgb, var(--overlay-danger) 38%, transparent)',
        background: 'color-mix(in srgb, var(--overlay-danger) 16%, transparent)',
        padding: 18,
        color: TEXT,
      }}
      >
        <div style={{ fontSize: 15, fontWeight: 700 }}>
          {this.props.pluginName} threw while rendering
        </div>
        <pre style={{
          marginTop: 12,
          padding: 12,
          borderRadius: 12,
          background: 'var(--overlay-bg-card-hover)',
          color: 'var(--overlay-danger)',
          whiteSpace: 'pre-wrap',
          fontSize: 12,
          lineHeight: 1.5,
        }}
        >
          {this.state.error}
        </pre>
      </div>
    );
  }
}

export default PluginsManager;
