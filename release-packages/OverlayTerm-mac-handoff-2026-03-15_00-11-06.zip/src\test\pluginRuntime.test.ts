import { describe, expect, it } from 'vitest';
import {
  definePlugin,
  derivePluginId,
  derivePluginName,
  isFrontendPluginFile,
} from '../components/pluginRuntime';

describe('pluginRuntime helpers', () => {
  it('recognizes supported frontend plugin files', () => {
    expect(isFrontendPluginFile({
      name: 'hello.tsx',
      path: 'M:\\OverlayTerm\\plugins\\hello.tsx',
      is_dir: false,
      modified: 1,
      extension: 'tsx',
    })).toBe(true);

    expect(isFrontendPluginFile({
      name: 'backend',
      path: 'M:\\OverlayTerm\\plugins\\backend',
      is_dir: true,
      modified: 1,
      extension: '',
    })).toBe(false);
  });

  it('derives stable plugin ids and display names from filenames', () => {
    expect(derivePluginId('My Cool_Plugin.tsx')).toBe('my-cool-plugin');
    expect(derivePluginName('my-cool_plugin.tsx')).toBe('My Cool Plugin');
  });

  it('returns plugin definitions untouched', () => {
    const component = () => null;
    const plugin = definePlugin({ name: 'Test', component });
    expect(plugin.name).toBe('Test');
    expect(plugin.component).toBe(component);
  });
});
