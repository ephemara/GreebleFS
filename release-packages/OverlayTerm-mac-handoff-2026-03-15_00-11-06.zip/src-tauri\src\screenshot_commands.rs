use std::borrow::Cow;
use std::path::Path;

use arboard::{Clipboard, ImageData};
use base64::{engine::general_purpose::STANDARD as BASE64_STANDARD, Engine as _};
use image::codecs::png::PngEncoder;
use image::{ColorType, ImageEncoder, ImageReader, RgbaImage};
use serde::{Deserialize, Serialize};
use xcap::Monitor;

#[derive(Debug, Serialize, Deserialize, Clone)]
pub struct SavedScreenshot {
    pub path: String,
    pub file_name: String,
    pub created_at: u128,
}

#[tauri::command]
pub async fn screenshot_capture_preview(
    x: i32,
    y: i32,
    width: u32,
    height: u32,
) -> Result<String, String> {
    validate_capture_region(width, height)?;

    let image = capture_absolute_region(x, y, width, height)?;
    let png_bytes = encode_png(&image)?;
    Ok(format!(
        "data:image/png;base64,{}",
        BASE64_STANDARD.encode(png_bytes)
    ))
}

#[tauri::command]
pub async fn screenshot_save_region(
    x: i32,
    y: i32,
    width: u32,
    height: u32,
    directory: String,
) -> Result<SavedScreenshot, String> {
    validate_capture_region(width, height)?;

    let image = capture_absolute_region(x, y, width, height)?;
    let dir_path = Path::new(&directory);
    std::fs::create_dir_all(dir_path).map_err(|e| e.to_string())?;

    let created_at = std::time::SystemTime::now()
        .duration_since(std::time::UNIX_EPOCH)
        .map_err(|e| e.to_string())?
        .as_millis();
    let file_name = format!("overlayterm-shot-{}.png", created_at);
    let full_path = dir_path.join(&file_name);

    image.save(&full_path).map_err(|e| {
        format!(
            "Failed to save screenshot to '{}': {}",
            full_path.display(),
            e
        )
    })?;

    Ok(SavedScreenshot {
        path: full_path.to_string_lossy().to_string(),
        file_name,
        created_at,
    })
}

#[tauri::command]
pub async fn screenshot_copy_image_to_clipboard(path: String) -> Result<(), String> {
    let image = ImageReader::open(&path)
        .map_err(|e| format!("Failed to open screenshot '{}': {}", path, e))?
        .with_guessed_format()
        .map_err(|e| format!("Failed to detect image format for '{}': {}", path, e))?
        .decode()
        .map_err(|e| format!("Failed to decode screenshot '{}': {}", path, e))?
        .to_rgba8();

    let mut clipboard =
        Clipboard::new().map_err(|e| format!("Failed to access system clipboard: {}", e))?;
    clipboard
        .set_image(ImageData {
            width: image.width() as usize,
            height: image.height() as usize,
            bytes: Cow::Owned(image.into_raw()),
        })
        .map_err(|e| format!("Failed to copy image to clipboard: {}", e))?;

    Ok(())
}

fn validate_capture_region(width: u32, height: u32) -> Result<(), String> {
    if width == 0 || height == 0 {
        return Err("Capture region must be at least 1 pixel wide and tall.".to_string());
    }
    if width > 16_384 || height > 16_384 {
        return Err("Capture region is too large.".to_string());
    }
    Ok(())
}

fn capture_absolute_region(x: i32, y: i32, width: u32, height: u32) -> Result<RgbaImage, String> {
    let (monitor, relative_x, relative_y) = resolve_monitor_region(x, y, width, height)?;
    monitor
        .capture_region(relative_x, relative_y, width, height)
        .map_err(|e| format!("Failed to capture screenshot region: {}", e))
}

fn resolve_monitor_region(
    x: i32,
    y: i32,
    width: u32,
    height: u32,
) -> Result<(Monitor, u32, u32), String> {
    let monitor = Monitor::from_point(x, y).map_err(|e| {
        format!(
            "Failed to locate monitor for capture point ({}, {}): {}",
            x, y, e
        )
    })?;

    let monitor_x = monitor
        .x()
        .map_err(|e| format!("Failed to read monitor origin: {}", e))?;
    let monitor_y = monitor
        .y()
        .map_err(|e| format!("Failed to read monitor origin: {}", e))?;
    let monitor_width = monitor
        .width()
        .map_err(|e| format!("Failed to read monitor width: {}", e))?;
    let monitor_height = monitor
        .height()
        .map_err(|e| format!("Failed to read monitor height: {}", e))?;

    let relative_x = x
        .checked_sub(monitor_x)
        .ok_or_else(|| "Capture origin falls outside the selected monitor.".to_string())?;
    let relative_y = y
        .checked_sub(monitor_y)
        .ok_or_else(|| "Capture origin falls outside the selected monitor.".to_string())?;

    if relative_x < 0 || relative_y < 0 {
        return Err("Capture origin falls outside the selected monitor.".to_string());
    }

    let relative_x = relative_x as u32;
    let relative_y = relative_y as u32;

    let within_width = relative_x
        .checked_add(width)
        .is_some_and(|end_x| end_x <= monitor_width);
    let within_height = relative_y
        .checked_add(height)
        .is_some_and(|end_y| end_y <= monitor_height);

    if !within_width || !within_height {
        return Err(format!(
            "Capture region extends beyond monitor bounds (monitor: {}x{}, requested offset: {}, {} size: {}x{}).",
            monitor_width, monitor_height, relative_x, relative_y, width, height
        ));
    }

    Ok((monitor, relative_x, relative_y))
}

fn encode_png(image: &RgbaImage) -> Result<Vec<u8>, String> {
    let mut png_bytes = Vec::new();
    let encoder = PngEncoder::new(&mut png_bytes);
    encoder
        .write_image(
            image.as_raw(),
            image.width(),
            image.height(),
            ColorType::Rgba8.into(),
        )
        .map_err(|e| format!("Failed to encode screenshot preview as PNG: {}", e))?;
    Ok(png_bytes)
}
