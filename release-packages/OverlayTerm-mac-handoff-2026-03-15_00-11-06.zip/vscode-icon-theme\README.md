# Zen Icon Theme

Zen Icon Theme is a standalone VS Code file icon theme by Zentako. It is built to make mixed codebases easier to scan at a glance, with 85 unique icons across KAIN, Rust, Unreal assets, shaders, config files, folders, major languages, and more obscure ecosystems.

Ships with 85 unique icons, 195 extension mappings, and 26 dedicated folder variants.

## Why it exists

Most icon themes collapse too many file types into generic badges. Zen Icon Theme takes the opposite approach:

- unique icons for individual ecosystems instead of recycled letters
- a dedicated KAIN icon for `.kn` files and `KAIN.toml`
- Unreal-aware coverage including `uasset` and `uproject`
- shader support for GLSL, HLSL, WGSL, and SPIR-V
- purposeful folder icons for source, tests, docs, config, build, and assets
- support for both major and more obscure languages, not just the usual defaults
- handcrafted SVG icons optimized for editor clarity

And yes, Rust gets an actual crab.

## Highlights

- Dedicated KAIN icon for `.kn` files, `KAIN.toml`, and the `kain` language id
- 85 unique icon definitions instead of generic letter badges
- Unique icons across major languages and lesser-covered languages like Zig, Erlang, OCaml, Clojure, Elixir, Haskell, R, Scala, and Ink
- Unreal Engine asset coverage including `uasset` and `uproject`
- Specialized shader icons for graphics and rendering workflows
- 26 folder icon variants for common project structure patterns
- Lightweight SVG icon set built for readability, not noise

## Preview

![Zen Icon Theme preview 1](https://cdn.zentako.xyz/other/firefox_6jdjuCgYFk.png)

![Zen Icon Theme preview 2](https://cdn.zentako.xyz/other/firefox_nKET0qQpK3.png)

## Activate

1. Install the extension from a `.vsix` or the VS Code Marketplace.
2. Open the Command Palette.
3. Run `Preferences: File Icon Theme`.
4. Select `Zen Icon Theme`.

## Coverage

- 85 unique icon definitions
- 195 file extension mappings
- 26 dedicated folder variants plus expanded states
- KAIN, Rust, Unreal, shader, config, asset, media, and archive coverage
- major and obscure languages across systems, scripting, functional, and graphics workflows

## Zentako

Zen Icon Theme is published by Zentako.

## License

MIT
