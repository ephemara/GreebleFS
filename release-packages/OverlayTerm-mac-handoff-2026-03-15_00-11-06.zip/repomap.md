# OverlayTerm Folder Map

```text
📂 OverlayTerm
    └── 📂 AppleCommand
        └── 📂 public
    └── 📂 mac-release
    └── 📂 public
        └── 📂 icons
    └── 📂 src
        └── 📂 assets
        └── 📂 components
        └── 📂 config
        └── 📂 input
        └── 📂 panels
        └── 📂 store
        └── 📂 test
    └── 📂 src-tauri
        └── 📂 capabilities
        └── 📂 gen
            └── 📂 schemas
        └── 📂 icons
        └── 📂 src
    └── 📂 vscode-icon-theme
        └── 📂 icons
```
